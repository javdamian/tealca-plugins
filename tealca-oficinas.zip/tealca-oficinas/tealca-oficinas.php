<?php

/**
 * Plugin Name:       Tealca Oficinas y Destinos
 * Plugin URI:        https://www.logoscorp.com/es/
 * Description:       Plugin para el registro de oficinas y destinos de Tealca
 * Version:           1.0.0
 * Requires at least: 5.6
 * Requires PHP:      7.2
 * Author:            Haron Acosta
 * Author URI:        https://www.logoscorp.com/es/
 * License:           MIT
 * Text Domain:       logoscorp
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Currently plugin version.
 */
define('TEALCA_OFICINAS_VERSION', '1.0.0');

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-plugin-name-activator.php
 */
function activate_tealca_oficinas()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-tealca-oficinas-activador.php';
    Tealca_Oficinas_Activator::activate();
}


/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-oficinas-tealca-deactivator.php
 */
function deactivate_oficinas_tealca() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-tealca-oficinas-deactivator.php';
	Tealca_Oficinas_Deactivator::deactivate();
}


register_activation_hook(__FILE__, 'activate_tealca_oficinas');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-tealca-oficinas.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_tealca_oficinas()
{
    // Creamos el objeto principal
    $oficinas = new Tealca_Oficinas();

    // Se crea el custom post de Oficinas y las categorias
    $oficinas->get_loader()->add_action('init', $oficinas, 'logos_tealca_oficinas_codex_init');

    //  Se corren todos los action
    $oficinas->run();
}

//Se inicia el plugin
add_action('init', 'run_tealca_oficinas');
