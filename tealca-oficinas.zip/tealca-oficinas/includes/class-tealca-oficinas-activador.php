<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.logoscorp.com/es/
 * @since      1.0.0
 *
 * @package    Oficinas_Tealca
 * @subpackage Oficinas_Tealca/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Oficinas_Tealca
 * @subpackage Oficinas_Tealca/includes
 * @author     Haron Acosta <hacosta@logoscorp.com>
 */
class Tealca_Oficinas_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
       
	}

}
