<?php

/**
 * 
 * Class Functionalities
 * 
 * The admin-specific functionality of the plugin.
 *
 * @link       www.logoscorp.com
 * @since      1.0.0
 *
 * @package    Oficinas_Tealca
 * @subpackage Oficinas_Tealca/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Functionalities
 * @subpackage Oficinas_Tealca/admin
 * @author     Jeykher Yendes <jpernia@logoscorp.com> & Jesús Chong <jchong@logoscorp.com>
 */
class Functionalities {

	/**
	 * The apiURL of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $apiURL      api Tealca URL.
	 */
    private $apiURL;

	/**
	 * The apiKEY of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $apiKEY    	api Tealca key.
	 */
    private $apiKEY;

	/**
	 * The path log import process file of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $logFilePath  Store path log file using to register logs on tealca import offices process.
	*/
	private $logFilePath;

	/**
	 * Holds the values to be used in the fields callbacks
	 *
	 * @since    1.0.0
	 * @access   private
	 * @param      array    $version    Array to stores plugins options.
	 */
	private $options;


	/**
     * __construct() method
	 * 
     * Initialize the class and set its properties and call import automatic process.
	 * 
	 * @since    1.0.0
	 * @access   public
	 * 
	 * Parameters.
	 *
	 * @param 	string       $logFilePath    Store path log file using to register logs on tealca import offices process on class.
	 * 
	*/
    public function __construct($logFilePath,$options) {
		$this->logFilePath = $logFilePath;
		$this->options = $options;
    }

	/**
     * addLog() method
	 * 
     * Add a new line log register on /app/tealca-oficinas.log file
	 *
	 * @since    1.0.0
	 * @access   public
	 * 
	 * Parameters.
	 *
	 * @param 	string       $msj    Store message to format and display on log file.
	 * 
	 */
    public function addLog($msj) {
        if(!empty(trim($msj))){
            date_default_timezone_set('America/Caracas');
            $time = date("Y-m-d h:i:s a", time());
            $fp = fopen($this->logFilePath, 'a+');
            fwrite($fp, $msj." - $time\n");
            fclose($fp);
        }
    }

	/**
	 * addBlankLineLog() {
	 * 
	 * Add a new blank line on import tealca office file log
	 * 
	 * @since    1.0.0
	 * @access   public
	 * 
	*/
	public function addBlankLineLog() {
		$fp = fopen($this->logFilePath, 'a+');
		fwrite($fp, "\n");
		fclose($fp);
	}

	/**
     * logosImportGetOffices() method
	 * 
     * Get the offices from Tealca external API & wordpress oficinas custom post type from wordpress tealca.
	 *
	 * @since    1.0.0
	 * @access   public
	 * 
	 * Parameters.
	 *
	 * @param 	boolean       $processAutomatic    Define if process is automatic cronjob or manual. default on true.
	 * 
	*/
    public function logosImportGetOffices($processAutomatic=true) {
			date_default_timezone_set('America/Caracas');
			$debugLogs=[];
			$time = date("Y-m-d h:i:s a", time());  
			$resultGlobal=[
				'typeResponse' => 'error',
				'error' => null,
				'message' => 'La importación de las oficinas no se pudo realizar. Consulte el administraodr y/o revise los logs',
				'debug'=> $this->options['debug']=='on'
			];
		try {
			if($processAutomatic) {
				$debugLogs[]=('Iniciando proceso automático de importación de oficinas');
			}
			else {
				$debugLogs[]=("* PROCESO DE IMPORTACION DE OFICINAS TEALCA - " . $time . " *\n");
				$debugLogs[]=('Iniciando proceso manual de importación de oficinas');
			}

			$this->apiUrl = $this->options['api_url'];
			$this->apiUser = $this->options['api_user'];
			$this->apiPassword = $this->options['api_password'];

			if(is_null($this->apiUrl) || is_null($this->apiUser) || is_null($this->apiPassword) ||
			empty($this->apiUrl) || empty($this->apiUser) || empty($this->apiPassword)){
				$debugLogs[]=("Credenciales de Api Oficinas Tealca, no configuradas.");
				throw new Exception('Credenciales de Api Oficinas Tealca incompletas o no configuradas.');
			}

			$debugLogs[]=("Obteniendo las oficinas de la api de Tealca.");

			//Get Token
			$requestToken = wp_remote_post($this->apiUrl.'account/login', [
				'method'      => 'POST',
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'timeout' => 300,
				'body'        => wp_json_encode([
					'login' => $this->apiUser,
					'password' => $this->apiPassword
				])
			]);
			
			$token=null;
			if ( is_wp_error( $requestToken ) ) {
				$response = $requestToken->get_error_message();
				throw new Exception('Ha ocurrido un error al obtener el token de autentificacion del api. '.$response);
			}else{
				$response = json_decode( wp_remote_retrieve_body( $requestToken ),true);
				$token=(isset($response['token']))?$response['token']:null;
			}

			if (!is_null($token)) {
				$args = array(
					'headers' => array(
						'Authorization' => 'Bearer '.$token,
						'Content-Type' => 'application/json'
					),
					'timeout'     => 300,
				);
				$response = wp_remote_get($this->apiUrl.'BusinessUnit/?status=1', $args);
				
				if(is_wp_error($response)) {
					$debugLogs[]=("El cron de importacion automática de oficinas ha fallado. No se han podido obtener las oficinas de la api de Tealca.");
					throw new Exception('Ha ocurrido un error al obtener las oficinas de la api de tealca. '.($response->get_error_message()));
				}else {
					$responseBody = wp_remote_retrieve_body($response);
					$officesAPI = json_decode($responseBody, true, 512, JSON_OBJECT_AS_ARRAY);
					$totalApiOffices = (isset($officesAPI)) ? count($officesAPI) : 0;
					$debugLogs[]=("El numero total de oficinas obtenida de la api de tealca es de: " . $totalApiOffices);
					$actions = [];
					$args = array(
						'post_type' => 'oficinas',
						'order'   => 'ASC',
						'posts_per_page'=> -1
					);
					$offices = new WP_Query($args);
					$officesCached = [];
					
					if($offices->have_posts()) {
						$debugLogs[]=("Identificando las oficinas del Custom Post Type de oficinas (interno) de Tealca.");
						while($offices->have_posts()) {
							$offices->the_post();
							$id = get_the_ID();
							$title = get_the_title();
							$featured_img_url = get_the_post_thumbnail_url($id, 'full');
							$taxonomies_names = wp_get_post_terms($id, 'ubicaciones', array("fields" => "names"));
							$taxonomies_filtered = '';
							foreach ($taxonomies_names as $tax_name) {
								$taxonomies_filtered .= $tax_name . ' ';
							}
							$fields = get_fields();
							
							$codigo = $fields['code'];
							$officeData = [
								'id'  => $id,
								'post' => [
									'name' => $title,
								],
								'fields' => $fields,
								'image' =>  $featured_img_url,
								'ubicaciones' => $taxonomies_filtered,
								'codigo' => $codigo,
								'action' => 'delete'
							];
							$officesCached[$codigo]=$officeData;
						}
					}
					$totalOfficesCached = count($officesCached);
					
					$debugLogs[]=("El número total de oficinas obtenidas de los custom type de oficinas es de: " . $totalOfficesCached);
					$actions = $this->compareDataOffices($officesCached, $officesAPI);
					$totalActions = count($actions);
					$debugLogs[]=("Se ha obtenido la lista de acciones a tomar para el proceso de importación");
					$debugLogs[]=("El número total de acciones es de " . $totalActions);
					$results = [];
					$debugLogs[]=("Aplicando acciones para las distintas oficinas importadas de la api de tealca.");
					$logActions = [
						"news" => [],
						"updated" => [],
						"deleted" => []
					];
					foreach ($actions as $action) {
						switch($action['action']) {
							case 'new':
								$result = $this->newOfficeTealca($action);
								$logActions['news'][]=[
									'codigo' => $action['code'],
									'nombre' => $action['name']					
								];
								break;
							case 'update':
								$result = $this->updateOfficeTealca($action);
								$logActions['updated'][]=[
									'id' => $action['id'],
									'codigo' => $action['code'],
									'nombre' => $action['name']
								];
								break;
							case 'delete':
								$result = $this->deleteOfficeTealca($action);
								$logActions['deleted'][]=[
									'id' => $action['id'],
									'codigo' => $action['codigo'],
									'nombre' => $action['post']['name']
								];
								break;
							default:
								$result = [];
								break;
						}
						array_push($results, $result);
					}
					$debugLogs[]=("Se han obtenido los siguientes resultados: ");
					$debugLogs[]=("Se han creado " . count($logActions['news']) . " nuevas oficinas.");
					$debugLogs[]=("Se han actualizado " . count($logActions['updated']) . " oficinas");
					$debugLogs[]=("Se han eliminado " . count($logActions['deleted']) . " oficinas");
					$resultGlobal['message']='El proceso de importación ha finalizado con éxito.';
					$resultGlobal['typeResponse']='success';
					
					if($resultGlobal['debug']){
						$resultGlobal['data']=[
							'tealcaOffices' => $totalApiOffices,
							'wordpressOffices' => $totalOfficesCached,
							'totalActions' => $totalActions,
							'actions' => $actions,
							'ImportOverview' => $logActions,
							'results' => $results
						];
						$resultGlobal['logs']=$debugLogs;
					}

					//Register logs in file logs
					foreach ($debugLogs as $msjLog) {
						$this->addLog($msjLog);
					}
					
				}
			}
		} catch (\Throwable $th) {
			$resultGlobal['message']=$th->getMessage();
		}
		return $resultGlobal;
    }

	/**
     * compareDataOffices() method
	 * 
     * Check & compare data obtained from external tealca api against wordpress offices custom post type to execute respective actions.
	 * 
	 * @since    1.0.0
	 * @access   private
	 * 
	 * Parameters.
	 *
	 * @param 	array       $cachedOffices    Store all offices custom post type obtained from wordpress.
	 * @param   array		$apiOffices		  Store all offices obtained from tealca api
	 *  
	 */    
	private function compareDataOffices($cachedOffices, $apiOffices) {
		$actions = [];
		foreach ($apiOffices as $apiOffice) {
			if(isset($cachedOffices[$apiOffice["code"]])){
				array_push($actions, [
					'action' => 'update',
					'id' => $cachedOffices[$apiOffice["code"]]['id'],
					'code' => $apiOffice["code"],
					"name" => $apiOffice["name"],
					"cityName" =>  $apiOffice["cityName"],
					"state" => $apiOffice["state"],
					"direction"  => $apiOffice["address"],
					"email" => $apiOffice["email"],
					"rif" => $apiOffice["rif"],
					"type" => $apiOffice["type"],
					"status" => $apiOffice["status"],
					"attributes" => $apiOffice["attributes"]
					/*"TELEFONOS" => $apiOffice["TELEFONOS"],
					"NOMBRE_ZONA" => $apiOffice["NOMBRE_ZONA"],
					"HorarioTrabajo" => $apiOffice["HorarioTrabajo"],
					"HoraMaximaRecep" => $apiOffice["HoraMaximaRecep"],
					"LATITUD" => $apiOffice["LATITUD"],
					"LONGITUD" => $apiOffice["LONGITUD"],
					"ZonaCobertura" => $apiOffice["ZonaCobertura"]*/
				]);
				$cachedOffices[$apiOffice["code"]]['action']='update';
			}
			else {
				array_push($actions, [
					'action' => 'new',
					'code' => $apiOffice["code"],
					"name" => $apiOffice["name"],
					"cityName" =>  $apiOffice["cityName"],
					"state" => $apiOffice["state"],
					"direction"  => $apiOffice["address"],
					"email" => $apiOffice["email"],
					"rif" => $apiOffice["rif"],
					"type" => $apiOffice["type"],
					"status" => $apiOffice["status"],
					"attributes" => $apiOffice["attributes"]
					/*"TELEFONOS" => $apiOffice["TELEFONOS"],*/
					/*"NOMBRE_ZONA" => $apiOffice["NOMBRE_ZONA"],*/
					/*"HorarioTrabajo" => $apiOffice["HorarioTrabajo"],
					"HoraMaximaRecep" => $apiOffice["HoraMaximaRecep"],
					"LATITUD" => $apiOffice["LATITUD"],
					"LONGITUD" => $apiOffice["LONGITUD"],
					"ZonaCobertura" => $apiOffice["ZonaCobertura"]*/
				]);
			}
		}
		$officesToDelete=array_filter($cachedOffices, function ($office) {
			return $office['action']=='delete';
		});
		$actions=array_merge($actions,$officesToDelete);
		return $actions;
	}

	/**
     * newOfficeTealca() method
	 * 
     * Create new office custom post type.
	 *
	 * @since    1.0.0
	 * @access   private
	 * 
	 * @param 	array   $data    Store all offices to be created by import process.
	 *  
	 */  
    private function newOfficeTealca($data) {
		$locations = get_terms(array(
			'taxonomy' => 'ubicaciones',
			'hide_empty' => false
		));
		$exists_state = false;
		$exists_city = false;
		foreach ($locations as $location) {
			if ($location->name == trim($data["state"])) {
				$exists_state = true;
				break;
			}
		}
		foreach ($locations as $location) {
			if ($location->name == $data["cityName"]) {
				$exists_city = true;
				break;
			}
		}
		if ($exists_state) {
			$state = get_term_by('name', trim($data["state"]), 'ubicaciones');
			$state_id  = intval($state->term_id);
		} 
		else {
			$state_insert = wp_insert_term(
				trim($data["state"]),
				'ubicaciones',
				array(
					'slug'        => strtolower(trim($data["state"])),
					'parent'      => 0,
				)
			);
			$state_id = $state_insert['term_id'];
		}
		if ($exists_city) {
			$city  = get_term_by('name', trim($data["cityName"]), 'ubicaciones');
			$city_id = intval($city->term_id);
		}
		else {
			$city_insert = wp_insert_term(
				trim($data["cityName"]),   
				'ubicaciones', 
				array(
					'slug'        => strtolower(trim($data["cityName"])),
					'parent'      => $state_id,
				)
			);
			$city_id = $city_insert['term_id'];
		}
		$post_data = array(
			'post_title'    => $data["name"],
			'post_status'  =>  ($data["status"]=="Activo" || $data["status"]=="1")?'publish':'private',
			'post_type' => 'oficinas',
		);
		$post_id = wp_insert_post($post_data);
		if (!is_wp_error($post_id)) {
			$taxonomy = 'ubicaciones';
			$locations = array($state_id, $city_id);
			wp_set_object_terms($post_id, $locations, $taxonomy);
			update_field('code', $data["code"], $post_id);
			//update_field('direction', $data["direction"], $post_id);
			update_field('state', $data["state"], $post_id);
			//update_field('cityName', $data["cityName"], $post_id);
			//update_field('attributes', $this->parse_atributes($data["attributes"]), $post_id);
			/*update_field('telefonos', $data["TELEFONOS"], $post_id);
			update_field('horarios', $data["HorarioTrabajo"], $post_id);
			update_field('latitud', $data["LATITUD"], $post_id);
			update_field('longitud', $data["LONGITUD"], $post_id);
			update_field('hora_de_recepcion_maxima', $data["HoraMaximaRecep"], $post_id);
			update_field('zona_de_cobertura', $data["ZonaCobertura"], $post_id);
			update_field('zoom', 10, $post_id);*/

			return [
				'success' => true,
				'officeCreated' => [
                    'id' => $post_id,
                    'codigo' => $data["code"],
                    'nombre' => $data["name"]
                ],
                'message' => "Se ha creado la oficina " . $data["name"] . " con codigo " . $data["code"]
			];
		} else {
            return [
                'success' => false,
                'officeCreated' => null,
                'message' => "no se ha podido crear la oficina " . $data["name"] . " con codigo " . $data['id']
            ];
		}
    }

	/**
     * updateOfficeTealca() method
	 * 
     * Update new office custom post type.
	 *
	 * @since    1.0.0
	 * @access   private
	 * 
	 * @param 	array   $data    Store all offices to be updated by import process.
	 *  
	 */  
    private function updateOfficeTealca($data) {	
		$city  = get_term_by('name', trim($data["cityName"]), 'ubicaciones');
		$city_id = intval($city->term_id);
		$state = get_term_by('name', trim($data["state"]), 'ubicaciones');
		$state_id  = intval($state->term_id);
		$post_data = array(
			'ID' => $data["id"],
			'post_title'   => $data["name"],
			'post_status'  =>  ($data["status"]=="Activo" || $data["status"]=="1")?'publish':'private',
			'post_type' => 'oficinas',
		);
		$post_id = wp_insert_post($post_data);
		if (!is_wp_error($post_id)) {
			$taxonomy = 'ubicaciones';
			$locations = array($state_id, $city_id);
			wp_set_object_terms($post_id, $locations, $taxonomy);
			update_field('code', $data["code"], $post_id);
			//update_field('direction', $data["direction"], $post_id);
			update_field('state', trim($data["state"]), $post_id);
			//update_field('cityName', $data["cityName"], $post_id);
			//update_field('attributes', $this->parse_atributes($data["attributes"]), $post_id);
			//update_field('horarios', $data["WorkingHours"], $post_id);
			/*update_field('telefonos', $data["TELEFONOS"], $post_id);
			update_field('latitud', $data["LATITUD"], $post_id);
			update_field('longitud', $data["LONGITUD"], $post_id);
			update_field('hora_de_recepcion_maxima', $data["HoraMaximaRecep"], $post_id);
			update_field('zona_de_cobertura', $data["ZonaCobertura"], $post_id);*/

			return [
				'success' => true,
				'officeUpdated' => [
                    'id' => $data['id'],
                    'codigo' => $data["code"],
                    'nombre' => $data["name"]
                ],
                'message' => "Se ha actualizado la oficina " . $data["name"] . " con codigo " . $data["id"]
			];
		} else {
            return [
                'success' => false,
                'officeUpdated' => null,
                'message' => "no se ha podido actualizar la oficina " . $data["name"] . " con codigo " . $data['id']
            ];
		}
    }

	/**
     * deleteOfficeTealca() method
	 * 
     * Delete new office custom post type.
	 *
	 *
	 * @since    1.0.0
	 * @access   private
	 * 
	 * @param 	array   $data    Store all offices to be removed by import process.
	 * 
	 */  
    private function deleteOfficeTealca($data) {
		$officeToDeleted = wp_delete_post($data['id'], true);
		if (is_null($officeToDeleted)) {
			return [
                'success' => false,
                'officeDeleted' => null,
                'message' => 'no se ha podido eliminar la oficina ' . $data['post']['name'] . ' con codigo ' . $data['id']
            ];
		} else {
            return [
				'success' => true,
				'officeDeleted' => [
					'id' => $data['id'],
					'codigo' => $data['code'],
					'nombre' => $data['post']['name']
				],
                'message' => 'Se ha eliminado la oficina ' . $data['post']['name'] . " con codigo " . $data['id']
			];
		}
    }

    // GETTERS METHODS 

	/**
     * getTealcaApiUrl() method
	 * 
     * Get the $apiURL property value from this class.
	 *
	 * @since    1.0.0
	 * @access   public
	 * 
	 */
    public function getTealcaApiUrl() {
        return isset($this->apiURL) ? $this->apiURL : ''; 
    }

	/**
     * getTealcaApiKey() method
	 * 
     * Get the $apiKEY property value from this class.
	 *
	 * @since    1.0.0
	 * @access   public
	 * 
	 */
    public function getTealcaApiKey() {
        return isset($this->apiKEY) ? $this->apiKEY : ''; 
    }

	/**
     * getLogFilePath() method
	 * 
     * Get the $logFIlePath property value from this class.
	 *
	 * @since    1.0.0
	 * @access   public
	 * 
	 */
    public function getLogFilePath() {
        return isset($this->logFilePath) ? $this->logFilePath : ''; 
    }

	// GETTERS METHODS
	/** 
	 * Return the api url of the settings
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 */
	public function get_api_url() {
		return isset($this->options['api_url']) ? $this->options['api_url'] : null;
	}

	/** 
	 * Return the api url of the settings
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 */
	public function get_api_key() {
		return isset($this->options['api_key']) ? $this->options['api_key'] : null;
	}


	
	public function parse_atributes($attrs){
		$arrs = array();
		
		$data = array_map(function ($item){
					return array($item['attributeName'] => $item['attributeValue']);
				}, $attrs);

				
		echo '<pre>'; print_r(array_keys($attrs, "WorkingHours")); echo '</pre>';

		return $arrs;
	}
}