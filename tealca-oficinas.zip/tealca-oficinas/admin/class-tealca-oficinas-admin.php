<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       www.logoscorp.com
 * @since      1.0.0
 *
 * @package    Oficinas_Tealca
 * @subpackage Oficinas_Tealca/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Oficinas_Tealca
 * @subpackage Oficinas_Tealca/admin
 * @author     Haron Acosta <hacosta@logoscorp.com>
 */
class Tealca_Oficinas_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @param      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @param      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Holds the values to be used in the fields callbacks
	 *
	 * @since    1.0.0
	 * @access   private
	 * @param      array    $version    Array to stores plugins options.
	 */
	private $options;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @access   public
	 * 
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->logos_tealca_office_custom_post();
		$this->options = get_option('plugin_oficinas_options');
		add_action('admin_menu', array($this, 'tealca_oficinas_add_submenu_page_to_offices'));
		add_action('admin_init', array($this, 'page_init'));
		add_action('rest_api_init', array($this, 'logos_tealca_register_endpoints'));
	}

	/**
	 * This function register admin endpoints 
	 *
	 * @since    1.0.0
	 * @access   public
	 * 
	 */
	public function logos_tealca_register_endpoints() {
		/**
		 * Endpoint offices
		 *
		 */
		register_rest_route('tealca-oficinas/v1', '/import-offices', array(
			'methods' => 'GET',
			'callback' => array($this, 'logos_tealca_get_offices_api'),
		));

		/**
		 * Endpoint offices
		 *
		 */
		register_rest_route('tealca-oficinas/v1', '/test', array(
			'methods' => 'GET',
			'callback' => array($this, 'test_dummies'),
		));
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 * @access   public
	 * 
	 */
	public function enqueue_styles_admin() {
		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Oficinas_Tealca_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Oficinas_Tealca_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/oficinas-tealca-admin.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 * @access   public
	 * 
	 */
	public function enqueue_scripts_admin() {
		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Oficinas_Tealca_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Oficinas_Tealca_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/oficinas-tealca-admin.js', array('jquery'), $this->version, false);
		wp_localize_script($this->plugin_name, 'logoscorp', ['ajaxurl' => site_url('/wp-json/tealca-oficinas/v1/')]);
	}

	/**
	 * Funcion to add the custom post office
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 */
	public function logos_tealca_office_custom_post() {
		// Se registra el Custom Post de las oficinas
		$labels = array(
			'name'                  => _x('Oficinas', 'Post type general name', 'textdomain'),
			'singular_name'         => _x('Oficina', 'Post type singular name', 'textdomain'),
			'menu_name'             => _x('Oficinas', 'Admin Menu text', 'textdomain'),
			'name_admin_bar'        => _x('Oficina', 'Add New on Toolbar', 'textdomain'),
			'add_new'               => __('Agregar oficina', 'textdomain'),
			'add_new_item'          => __('Agregar nueva oficina', 'textdomain'),
			'new_item'              => __('Nueva oficina', 'textdomain'),
			'edit_item'             => __('Editar oficina', 'textdomain'),
			'view_item'             => __('Ver oficina', 'textdomain'),
			'all_items'             => __('Todas las oficinas', 'textdomain'),
			'search_items'          => __('Buscar oficinas', 'textdomain'),
			'parent_item_colon'     => __('Parent ofices:', 'textdomain'),
			'not_found'             => __('No se encontraron oficinas.', 'textdomain'),
			'not_found_in_trash'    => __('No se encontraron oficinas en la papelera.', 'textdomain'),
			'featured_image'        => _x('Imagen de la oficina', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain'),
			'set_featured_image'    => _x('Imagen principal de la oficina', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain'),
			'remove_featured_image' => _x('Quitar imagen principal', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain'),
			'use_featured_image'    => _x('Usar imagen principal', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain'),
			'archives'              => _x('Archivo de Oficinas ', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain'),
			'insert_into_item'      => _x('Insertar una nueva oficina', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain'),
			'uploaded_to_this_item' => _x('Subir a estar oficina', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain'),
			'filter_items_list'     => _x('Filtrar de la lista de oficinas', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain'),
			'items_list_navigation' => _x('Navegacion de la lista de oficinas', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain'),
			'items_list'            => _x('Lista de Oficinas', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain'),
		);
		$args = array(
			'labels' => $labels,
			'public' => true,
			'show_ui' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'rewrite' => array('slug' => 'oficinas/%ubicaciones%'),
			'query_var' => true,
			'menu_icon' => plugin_dir_url(__FILE__) . 'img/logo_blanco_mobile.png',
			'capabilities' => array(
				'create_post' => false,
			),
			'map_meta_cap' => true,
			'supports'  => array('title'),
		);
		
		function wpa_category_post_link( $post_link, $id = 0 ){
			$post = get_post($id);  
			if ( is_object( $post ) ){
				$terms = wp_get_object_terms( $post->ID, 'ubicaciones' );
				if( $terms ){
					$slugs ='';
					$countTerms = count($terms)-1;
					for ($i=0; $i <= $countTerms ; $i++) { 
						if ($i == $countTerms) {
							$slugs .= $terms[$i]->slug;
						}else{
							$slugs .= $terms[$i]->slug.'/';
						}
					}
					return str_replace( '%ubicaciones%' , $terms[0]->slug , $post_link );
				}
			}
			return $post_link;  
		}
		add_filter( 'post_type_link', 'wpa_category_post_link', 1, 3 );
		register_post_type('oficinas', $args);
		// Se registra la taxonomia de Ubicaciones para las Oficinas 
		$labels = array(
			'name'              => esc_html__('Ubicaciones', 'logoscorp'),
			'singular_name'     => esc_html__('Ubicación', 'logoscorp'),
			'search_items'      => esc_html__('Buscar Ubicaciones', 'logoscorp'),
			'all_items'         => esc_html__('Todas las Ubicaciones', 'logoscorp'),
			'parent_item'       => esc_html__('Ubicación principal', 'logoscorp'),
			'parent_item_colon' => esc_html__('Ubicación principal:', 'logoscorp'),
			'edit_item'         => esc_html__('Editar ubicación', 'logoscorp'),
			'update_item'       => esc_html__('Actualizar ubicaciones', 'logoscorp'),
			'add_new_item'      => esc_html__('Agregar nueva ubicación', 'logoscorp'),
			'new_item_name'     => esc_html__('Nueva ubicación', 'logoscorp'),
			'menu_name'         => esc_html__('Ubicaciones', 'logoscorp'),
			'not_found'         => esc_html__("Actualmente no tiene ubicaciones registradas.", 'logoscorp'),
		);
		$location_args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'show_in_rest'      => false,
			'capabilities' => array(
				'assign_terms'  =>   'assign_ubicaciones',
			),
		);
		register_taxonomy('ubicaciones', array('oficinas'), $location_args);
	}

	
	/**
	 * Funcion to call manual import offices process
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 */
	public function logos_tealca_get_offices_api() {
		include_once(plugin_dir_path(__FILE__) . 'Functionalities.php');
		$import_file_logs = WP_PLUGIN_DIR.'/../cache/tealca-oficinas.log';
		$_funcionalities = new Functionalities($import_file_logs,$this->options);
		$resultJson = $_funcionalities->logosImportGetOffices(false);
		$_funcionalities->addLog(json_encode($resultJson));
		$_funcionalities->addBlankLineLog();
		wp_send_json($resultJson);
	}

	/**
	 * Convert object in array
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 */
	public function convert_object_to_array($object) {
		return (array) $object;
	}

	/**
	 * Register the sub-menu in the custom offices.
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 */
	public function tealca_oficinas_add_submenu_page_to_offices() {
		add_submenu_page(
			'edit.php?post_type=oficinas',
			__('Importar oficinas', 'tealca-oficinas'),
			__('Opciones de oficinas', 'tealca-oficinas'),
			'manage_options',
			'oficinas_import',
			array($this, 'tealca_oficinas_import_display')
		);
	}

	/**
	 * Display import offices
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 */
	public function tealca_oficinas_import_display() {
		// Set class property
		$this->options = get_option('plugin_oficinas_options');
		?>
				<div class="wrap">
					<h1>Oficinas API</h1>
					<form method="post" action="options.php">
						<?php
						settings_errors();
						// This prints out all hidden setting fields
						settings_fields('plugin_oficinas_option_group');
						do_settings_sections('plugin_oficinas_settings_page');
						submit_button();
						?>
					</form>
				</div>
		<?php
		echo '<div class="wrap">
		
		<h1>Importar oficinas</h1>';
		echo '<form id="button-import" method="get">';
		echo ' <button type="submit" value="Importar" class="button button-primary">Importar</button>';
		echo '</form></div>';
	}

	/**
	 * Register and add settings
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 */
	public function page_init() {
		register_setting(
			'plugin_oficinas_option_group', // Option group
			'plugin_oficinas_options', // Option name
			array($this, 'sanitize') // Sanitize
		);
		add_settings_section(
			'plugin_oficinas_setting_section', // ID
			'Configuración de API', // Title
			array($this, 'print_section_info'), // Callback
			'plugin_oficinas_settings_page' // Page
		);

		add_settings_field(
			'api_url',
			'API URL Domain',
			array($this, 'api_url_callback'),
			'plugin_oficinas_settings_page',
			'plugin_oficinas_setting_section',
			array( 
            'class'=> 'tr-admin-input',
            )
		);
		add_settings_field(
			'api_user', // ID
			'API User', // Title 
			array($this, 'api_user_callback'), // Callback
			'plugin_oficinas_settings_page', // Page
			'plugin_oficinas_setting_section', // Section
			array( 
            'class'=> 'tr-admin-input',
            )
		);
		add_settings_field(
			'api_password', // ID
			'API Password', // Title 
			array($this, 'api_password_callback'), // Callback
			'plugin_oficinas_settings_page', // Page
			'plugin_oficinas_setting_section', // Section
			array( 
            'class'=> 'tr-admin-input',
            )
		);
		
		add_settings_field(
			'debug',
			'Debug',
			array($this, 'debug_callback'),
			'plugin_oficinas_settings_page',
			'plugin_oficinas_setting_section',
			array( 
			'class'=> '',
			)
		);
	}

	/**
	 * Sanitize each setting field as needed
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 * @param array $input Contains all settings fields as array keys
	 */
	public function sanitize($input) {
		$new_input = array();
		if (isset($input['api_user']))
			$new_input['api_user'] = sanitize_text_field($input['api_user']);

		if (isset($input['api_url']))
			$new_input['api_url'] = sanitize_text_field($input['api_url']);

		if (isset($input['api_password']))
			$new_input['api_password'] = sanitize_text_field($input['api_password']);

		if (isset($input['debug']))
			$new_input['debug'] = sanitize_text_field($input['debug']);
		
		return $new_input;
	}

	/** 
	 * Print the Section text
	 * 
	 * @since    1.0.0
	 * @access   public 
	 * 
	 */
	public function print_section_info() {
		print 'Por favor ingrese las opciones:';
	}

	
	public function api_url_callback() {
		printf(
			'<input type="text" id="api_url" name="plugin_oficinas_options[api_url]" value="%s" />',
			isset($this->options['api_url']) ? esc_attr($this->options['api_url']) : ''
		);
	}

	public function api_user_callback() {
		printf(
			'<input type="text" id="api_user" name="plugin_oficinas_options[api_user]" value="%s" />',
			isset($this->options['api_user']) ? esc_attr($this->options['api_user']) : ''
		);
	}

	public function api_password_callback() {
		printf(
			'<input type="text" id="api_password" name="plugin_oficinas_options[api_password]" value="%s" />',
			isset($this->options['api_password']) ? esc_attr($this->options['api_password']) : ''
		);
	}

	public function debug_callback() {
		printf(
			'<input type="checkbox" id="debug" name="plugin_oficinas_options[debug]" %s />',
			(isset($this->options['debug']) && $this->options['debug']=='on') ? 'checked' : ''
		);
	}

	// GETTERS METHODS
	public function get_api_url() {
		return isset($this->options['api_url']) ? $this->options['api_url'] : null;
	}

	public function get_api_user() {
		return isset($this->options['api_user']) ? $this->options['api_user'] : null;
	}

	public function get_api_password() {
		return isset($this->options['api_password']) ? $this->options['api_password'] : null;
	}

	public function is_debug_enable() {
		return isset($this->options['debug']) ? $this->options['debug']=='on':false;
	}

}
