(function($) {
    "use strict";

    console.log('plugin_oficinas_debug', typeof plugin_oficinas_debug);
    window.addEventListener("DOMContentLoaded", () => {
            const buttonImport = document.getElementById("button-import");
            buttonImport.addEventListener("click", import_offices, false);
        },
        false
    );

    const import_offices = async(e) => {
        e.preventDefault();
        console.log("Proceso de Importación de oficinas Tealca manual");
        console.log("Importando oficinas...");
        alert('El proceso de importación de oficinas tardará unos segundos, sea paciente');
        try {
            const url = `${logoscorp.ajaxurl}import-offices`;
            const headers = new Headers();
            const fecthConfig = {
                method: "GET",
                credentials: "same-origin",
                headers: headers
            };
            let response = await fetch(url, fecthConfig);
            let data = await response.json();
            console.log("Respuesta obtenida de la api: ");
            console.log(data);
            if (typeof data.message != 'undefined') {
                alert(data.message);
            }
        } catch (error) {
            console.log("Error: ");
            console.log(error);
        }
    };

})(jQuery);

console.log('plugin_oficinas_debug', typeof plugin_oficinas_debug);