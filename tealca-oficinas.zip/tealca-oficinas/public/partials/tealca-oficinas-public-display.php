<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.logoscorp.com/es/
 * @since      1.0.0
 *
 * @package    Tealca_Oficinas
 * @subpackage Tealca_Oficinas/public
 */

$statesHtml = '<option value="0" selected="true" disabled="disabled" >Seleccione un estado ...</option>';

/* Trozo de codigo original */

/*foreach ($states as $state) {
  $statesHtml .= '<option value="' . $state->term_id . '" data-lat="' . $state->latitud . '" data-lon="' . $state->longitud . '" data-zoom="' . $state->zoom . '" data-name="'. $state->name .'">' . $state->name . '</option>';
}*/

/* Trozo de codigo original */

/* Codigo nuevo de jeykher */


foreach ($this->states as $term_id => $state) {
  $statesHtml .= '<option value="' . $state->term_id . '" data-slug="' . $state->slug . '" data-name="' . $state->name . '">' . $state->name . '</option>';
}

/* Codigo nuevo de jeykher */

$officesHtml = '';

foreach ($allDataOffices as $office) {
  $office_name = (isset($office['post']['name'])) ? $office['post']['name'] : '';
  $office_codigo = (isset($office['fields']['code'])) ? $office['fields']['code'] : '';
  $office_direccion = (isset($office['fields']['direction'])) ? $office['fields']['direction'] : '';
  $office_horarios = (isset($office['fields']['horarios'])) ? $office['fields']['horarios'] : '';
  $office_telefonos = (isset($office['fields']['telefonos'])) ? $office['fields']['telefonos'] : '';
  $latitud = (isset($office['fields']['latitud'])) ? $office['fields']['latitud'] : '';
  $longitud = (isset($office['fields']['longitud'])) ? $office['fields']['longitud'] : '';
  $zoom = (isset($office['fields']['zoom'])) ?  $office['fields']['zoom']  : '';
  $slug = (isset($office['slug'])) ? $office['slug'] : '';

  $officesHtml .= '
    <div class="accordion-item">
      <h2 class="accordion-header" id="flush-headingOne">
        <button class="accordion-button collapsed" type="button" data-ubicaciones="' . $office['ubicaciones'] . '" data-lon="' . $longitud . '" data-lat="' . $latitud . '" data-z="' . $zoom . '" data-bs-toggle="collapse" data-bs-target="#flush-' . $office['post']['id'] . '" aria-expanded="false" aria-controls="flush-' . $office['post']['id'] . '" onclick="show_office_location(event)">
        ' . $office['post']['name'] . '
        </button>
      </h2>
      <div id="flush-' . $office['post']['id'] . '" class="accordion-collapse collapse" aria-labelledby="flush-heading' . $office['post']['id'] . '" data-bs-parent="#accordionOffices">
        <div class="table-responsive">
        <table class="table table-sm">
        <tbody id="office-detail-body">
        <tr>
          <th scope="row">Nombre:</th>
          <td>
          ' . $office_name . '
          </td>
        </tr>
        <tr>
          <th scope="row">Codigo:</th>
          <td>
          ' . $office_codigo . '
          </td>
        </tr>
        <tr>
          <th scope="row">Direccion:</th>
          <td>
          ' . $office_direccion . '
          </td>
        </tr>
        <tr>
          <th scope="row">Horario:</th>
          <td>
          ' . $office_horarios . '
          </td>
        </tr>
      
        <tr>
          <th scope="row">Telefonos:</th>
          <td>
          ' . $office_telefonos . '
          </td>
        </tr>
      </tbody>
      </table>
        </div>
      </div>
    </div>';
}

$html = '
  <div class="row">
    <div class="col-md-5">
      <form>
        <select class="form-select form-select-sm mb-3" name="state" id="state">
          ' . $statesHtml . '
        </select>
        <select class="form-select form-select-sm mb-3" name="city" id="city">
          <option value="null">Seleccione una ciudad</option>
        </select>
      </form>
  
      <div class="accordion accordion-flush" id="accordionOffices">
          ' .  $officesHtml . '
      </div>
    </div>
  
    <div class="col-md-7">
      <iframe
        src="https://www.google.com/maps/d/embed?mid=' . $atts['mapid'] . '&ll=7.075187981158469%2C-64.5912201994032&z=5"
        width="650"
        height="350"
        id="iframe-map"
        class="iframe-map"
      ></iframe>
    </div>
  </div>
';

$officesListHtml = '
  <div class="offices-selection">
    <form class="et_pb_row">
      <div class="et_pb_column et_pb_column_1_2 et_pb_column_2">
        <fieldset class="col-12 input-field">
          <label for="state" class="form-label">Estado</label>
          <select class="form-select" name="state" id="state">
            '.$statesHtml.'
          </select>
        </fieldset>
      </div>
      <div class="et_pb_column et_pb_column_1_2 et_pb_column_2">
        <fieldset class="input-field">
          <label for="destination-city" class="form-label">Ciudad o área</label>
          <select class="form-select" name="city" id="city">
            <option value="null">Seleccione una ciudad</option>
          </select>
        </fieldset>
      </div>
    </form>
    <div class="et_pb_row offices-select">
      <div class="et_pb_column et_pb_column_4_4">
        <div class="summit-calc-btn">
          <button id="display-all-offices" type="submit" class="btn">
            <span class="summit-text">VER TODAS LAS OFICINAS</span>
          </button>
        </div>
      </div>
    </div>
    <div class="accordion accordion-flush" id="accordionOffices">
    </div>
  </div>';