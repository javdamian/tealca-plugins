<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://www.logoscorp.com/es/
 * @since      1.0.0
 *
 * @package    Tealca_Oficinas
 * @subpackage Tealca_Oficinas/includes
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Tealca_Oficinas
 * @subpackage Tealca_Oficinas/public
 * @author     Haron Acosta <hacosta@logoscorp.com>
 */
class Tealca_Oficinas_Public
{


	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Tealca_Oficinas_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $tealca_oficina    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * The mapid.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string   $mapid   The map id of the plugin
	 */
	protected $mapid;

	/**
	 * The mapid.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string   $api_url   The API url
	 */
	protected $api_url;

	/**
	 * The office.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      array   $offices   The Office
	 */
	protected $offices;

	/**
	 * Holds the values to be used in the fields callbacks
	 *
	 * @since    1.0.0
	 * @access   private
	 * @param      array    $version    Array to stores plugins options.
	 */
	 private $options;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	public function __construct($plugin_name, $version, $loader)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;

		// Pass the loader
		$this->loader  = $loader;
		$this->options = get_option('plugin_oficinas_options');
		$this->api_url=$this->get_api_url();
		$this->api_user=$this->get_api_user();
		$this->api_password=$this->get_api_password();
		$this->is_debug_enable=$this->is_debug_enable();
		// Shortcode for show the states and container 
		add_shortcode('estados', array($this, 'logos_tealca_shortcode_states'));
		add_shortcode('PTO_GET_OFI_ID', array($this, 'logos_tealca_shortcode_get_office_by_id'));
		add_shortcode('PTO_GET_OFI_ATTRS', array($this, 'logos_tealca_shortcode_get_office_attrs'));
		// Shortcode to show all the states and cities 
		//add_shortcode('all_states', array($this, 'logos_tealca_shortcode_states'));

		$this->loader->add_action('rest_api_init', $this, 'logos_tealca_register_endpoints');

		$this->offices = $this->getAllOffices();
	}

	private function getAllOffices(){

		$args = array(
			'post_type' => 'oficinas',
			'order'   => 'ASC',
			'posts_per_page' => 5000
		);

		$offices = new WP_Query($args);
		return $offices;
	}

	/**
	 * This function register public endpoints 
	 *
	 * @since    1.0.0
	 */
	public function logos_tealca_register_endpoints()
	{

		/**
		 * Endpoint offices
		 *
		 */
		register_rest_route('tealca-oficinas/v1', '/offices', array(
			'methods' => 'GET',
			'callback' => array($this, 'logos_tealca_get_offices'),
		));

		/**
		 * Endpoint cities
		 *
		 */
		register_rest_route('tealca-oficinas/v1', '/cities', array(
			'methods' => 'POST',
			'callback' => array($this, 'logos_tealca_get_cities'),
		));
	}


	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles_public()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style('bootstrap-grid', plugin_dir_url(__FILE__) . 'libs/bootstrap.min.css', array(), '5.0.0', 'all');
		wp_enqueue_style('bootstrap-table', plugin_dir_url(__FILE__) . 'libs/table.css', array(), '5.0.0', 'all');

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/tealca-oficinas-public.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts_public()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */


		//  Trato de regresar el ID del mapa pero no me regresa el valor lo hace null
		$map = $this->mapid;

		wp_enqueue_script('bootstrap', plugin_dir_url(__FILE__) . 'js/bootstrap.min.js', array('jquery'), $this->version, false);
		wp_enqueue_script('fuse', plugin_dir_url(__FILE__) . 'libs/fuse.js', array(), $this->version, false);

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/tealca-oficinas-public.js', array('jquery'), $this->version, false);
		wp_localize_script($this->plugin_name, 'logoscorpOffice', ['ajaxurl' => site_url('/wp-json/tealca-oficinas/v1/')]);
	}
	

	/**
	 *  Get the list of states
	 * 
	 * @since    1.0.0
	 */

	public function logos_tealca_shortcode_states($atts)
	{

		$this->mapid = $atts['mapid'];

		$allDataOffices = [];
		$ubicaciones = [];
		$count = 0;

		if ($this->offices->have_posts()) {
			
			while ($this->offices->have_posts()) {
				$this->offices->the_post();

				$title = get_the_title();

				$id = get_the_ID();

				$slug = get_post_field( 'post_name', get_the_ID() );

				$featured_img_url = get_the_post_thumbnail_url($id, 'full');

				$taxonomies = wp_get_post_terms($id, 'ubicaciones',  array("fields" => "all"));
				$taxonomies_filtered = '';
				foreach ($taxonomies as $tax) {
					$taxonomies_filtered .= $tax->name . ' ';
					
				}

				$officeData = [
					'post' => [
						'id'  => $id,
						'name' => $title,
					],
					'fields' => get_fields(),
					'image' =>  $featured_img_url,
					'ubicaciones' => $taxonomies_filtered,
					'slug' => $slug 
				];

				array_push($allDataOffices,	$officeData);
			}
		}

		$taxonomyTerms = get_terms( array( 'taxonomy' => 'ubicaciones', 'hide_empty' => true, 'parent'=> 0) );

		
		foreach ($taxonomyTerms as $key => $taxonomy) {
			$taxonomyTerms[$key]->ciudades = get_terms( array( 'taxonomy' => 'ubicaciones', 'hide_empty' => true, 'parent'=> $taxonomy->term_id) );
		}
		$this->states = $taxonomyTerms;

		// echo '<script>'; 
		// echo 'var ubicaciones_data ='.json_encode($this->states);
		// echo '</script>';
		echo '<script>(new TealcaOficinasPrincipalPage('.json_encode($this->states).', '.( ($this->is_debug_enable)?'true':'false' ).').start())</script>';
		
		require_once plugin_dir_path(dirname(__FILE__)) . 'public/partials/tealca-oficinas-public-display.php';

		/* If the map id is null no use the mapid */

		//REVISAR ESTE COMPORTAMIENTO
		if ($atts['mapid'] == 'null') {

			return $officesListHtml;

		} else {

			return $html;

		}
	}

	private function getMetadataOfficeByCode($codeOffice){
		$resultMetadata=[];
		try {
			$args = array(
				'post_type' => 'oficinas',
				//'post_status' => 'publish',
				'meta_key'		=> 'code',
				'meta_value'	=> $codeOffice,
			);
			$current_post = new WP_Query($args); 
	
			if($current_post->have_posts()) : 
				$first_post = $current_post->posts[0];	
				$postMetadata=get_post_meta($first_post->ID);	
				if(isset($postMetadata['url_google_map'][0])){
					$resultMetadata['url_google_map']=$postMetadata['url_google_map'][0];
				}
			endif;
		} catch (\Throwable $th) {
			//throw $th;
		}
		return $resultMetadata;
	}

	/**
	 *  Get the office by state
	 * 
	 * @since    1.0.0
	 */
	public function logos_tealca_shortcode_get_office_by_id($atts){

		//tiempo en segundos
        $tiempoLimite=3600; //1 hora
        //$tiempoLimite=300; //5 min
        

		// CONSULTAR EL ENDPOINT DE TEALCA PARA OBTENER LOS DATOS DE ESTA OFICINA $ATTS['ID'] 
		// GUARDAR LOS DATOS EN VARIABLE DE SESSION DE WP LOS DATOS DE LA OFICINA ATADOS AL ID
		/*if(!session_id()) {
			$lifetime = strtotime('+5 minutes', 0);
			session_set_cookie_params($lifetime);
			session_start();
		}*/

		//mapa de estructura de datos con respecto al endpoint
		$attrsMap=[
			"resumen"=>[
				"name",
				"code",
				"cityName"
			],
			"detalleDeContacto"=>[
				"direction",
				"email",
				"instagram",
				"Teléfono",
				"Whatsapp"
			],
			"horarios"=>[
				"WorkingHours"
			],
			"comoLlegar"=>[
				"DD-EstacionMetro"
			],
			"caracteristicasPresentes"=>[
				"DD-Acceso Discapacitados",
				"DD-Estacionamiento Gratis",
				"DD-Estacionamiento Pago",
				"DD-Recoger Paquete"
			],
			"mapa"=>[
				"ZonasCubiertas"
			],
			"oficinasCercanas"=>[
				"oficinasCercanas"
			]
			
		];
		
		/*
			ESTOS CAMPOS NO ESTAN ESTRUCTURADOS EN EL XD
				"apiladorDeCarga"		=> ["DD-Apilador para carga"],
				"plantaElectrica"		=> ["DD-Planta Eléctrica"],
				"embalaje"				=> ["DD-Embalaje"],
				"domicilio"				=> ["DD-Domicilio"],
				"anoFundacion"			=> ["Año Fundación"],
				"puntoDeVenta"			=> ["MP-Punto de venta"],
				"pagoMovil"				=> ["MP-Pago Móvil"],
				"transferencia"			=> ["MP-Transferencias"],
		*/

		if (isset($atts['id']) && !empty($atts['id'])) {

			if (!isset($_SESSION['PTO_DETAILS'])) {
				//ASEGURAR DE QUE EXISTE LA VARIABLE SESSION QUE ALMACENE LAS OFICINAS CACHEADAS COMO SESSION
				$_SESSION['PTO_DETAILS']=[];
			}
			$codigo=$atts['id'];
			$linkGooglMapCurrentOffice=null;
			$requestOfficeInApiTealca=true;
			if (!$this->is_debug_enable &&
			isset($_SESSION['PTO_DETAILS'][$codigo]) && 
			(time() - $_SESSION['PTO_DETAILS'][$codigo]['timeExpiration']) <= $tiempoLimite) {
				//$_SESSION['PTO_DETAILS'][$codigo]['timeExpiration'] = time();
				$requestOfficeInApiTealca=false;
			}

			if($requestOfficeInApiTealca){
				//CONSULTAR OFICINA
				$officeRequest = $this->logos_tealca_call_office($atts['id']);
				if($officeRequest['typeResponse']=='success'){
					$office=$officeRequest['office'];

					//DETALLE DE ATRIBUTOS MAP
					$officeDetails = $this->mapAtrrOffice($attrsMap, $office);

					$metadataPost=$this->getMetadataOfficeByCode($codigo);
					$officeDetails=array_merge($officeDetails,$metadataPost);

					$office=$officeRequest['office'];
					
					//SESSION PARA DETALLE DE OFICINAS
					$this->setSessionPTO($codigo, $officeDetails);
				}
			}

			if(isset($_SESSION['PTO_DETAILS'][$codigo]['mapa']['latitud']) && !empty($_SESSION['PTO_DETAILS'][$codigo]['mapa']['latitud']) && isset($_SESSION['PTO_DETAILS'][$codigo]['mapa']['length']) && !empty($_SESSION['PTO_DETAILS'][$codigo]['mapa']['length'])){
				$linkGooglMapCurrentOffice='https://www.google.com/maps/place/'.$_SESSION['PTO_DETAILS'][$codigo]['mapa']['latitud'].','.$_SESSION['PTO_DETAILS'][$codigo]['mapa']['length'];
			}
			

			$divContent ='<div class="col-md-6 col-sm-12 mt-2">';
			$divContent .= '<div class="text-dec title-details-offices"><b>'.$_SESSION['PTO_DETAILS'][$codigo]['resumen']['name'].'</b></div>';
			$divContent .='</div>';

			$divContent .='<div class="col-md-6 col-sm-12 mt-2">';
			$divContent .= '<div class="text-dec my-3"> Ciudad: '.$_SESSION['PTO_DETAILS'][$codigo]['resumen']['ciudad'].'</div>';
			$divContent .= '<div class="text-dec my-3"> Codigo: '.$_SESSION['PTO_DETAILS'][$codigo]['resumen']['codigo'].'</div>';
			$divContent .='</div>';
				
			$html = '<div class="row">'.$divContent.'</div>';

			if(!is_null($linkGooglMapCurrentOffice)){
				$html.='<script>';
				$html.=' jQuery(document).ready(function() { if(jQuery(".tc-office-map-app a").length>0){jQuery(".tc-office-map-app a").attr("href","'.$linkGooglMapCurrentOffice.'");}  });';
				$html.='</script>';
			}
			
			//if($this->is_debug_enable){
				$html.='<script>';
					//$html.=' try{';
						$html.='console.log("REQUEST API TRALCA '.( (($requestOfficeInApiTealca)?'SI':'NO') ).'");';
						$html.='console.log("linkGooglMapCurrentOffice'.( (($linkGooglMapCurrentOffice)) ).'");';

						//$html.='console.log("debug enable");';
						//$html.='console.log("debug office",'.$codigo.',JSON.parse("'.utf8_decode(json_encode($officeRequest)).'");';
						//$html.='console.log("debug office",'.$codigo.','.json_encode($officeRequest).'");';
						//$html.='console.log("debug office in Session",'.$codigo.','.utf8_decode(json_encode($_SESSION['PTO_DETAILS'][$codigo])).');';
					//$html.='} catch (error) {console.log("Error",error);} ';
				
					//tc-office-map-app
				$html.='</script>';
			//}

			return $html;
		}
	}

	public function logos_tealca_shortcode_get_office_attrs($atts){
		if (isset($atts['id']) && isset($atts['field'])) {
			$codigo = $atts['id'];
			$attr   = $atts['field'];
			if ($attr == 'resumen' && isset($_SESSION['PTO_DETAILS'][$codigo][$attr])) {

				$divContent ='<div class="col-md-6 col-sm-12 mt-2">';
				if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['ciudad'])) {
					foreach ($_SESSION['PTO_DETAILS'][$codigo][$attr]['ciudad'] as $key => $value) {
						$divContent .= '<div class="text-dec"> Ciudad: '.$value.'</div>';
					}
				}
				if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['codigo'])) {
					foreach ($_SESSION['PTO_DETAILS'][$codigo][$attr]['codigo'] as $key => $value) {
						$divContent .= '<div class="text-dec"> Codigo: '.$value.'</div>';
					}
				}
				$divContent .='</div>';

				$html = '<div class="row">'.$divContent.'</div>';

				return $html;
			}
			if ($attr == 'detallesDeContacto' && isset($_SESSION['PTO_DETAILS'][$codigo][$attr]) ) {

				$divContent ='<div class="col-md-6 col-sm-12 mt-2">';
					$divContent .= '<div class="row">';
					$divContent .= '<div class="col-md-4 col-sm-6 my-2 addres">Dirección: </div><div class="col-md-8 col-sm-6 my-2 text-dec">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['direccion'].'</div>';
					$divContent .='</div>';

					$divContent .= '<div class="row">';
					$divContent .= '<div class="col-md-4 col-sm-6 my-2 email-details">Email: </div><div class="col-md-8 col-sm-6 my-2 text-dec">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['email'].'</div>';
					$divContent .='</div>';

					$divContent .= '<div class="row">';
					$divContent .= '<div class="col-md-4 col-sm-6 my-2">Instagram: </div><div class="col-md-8 col-sm-6 my-2 text-dec">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['instagram'].'</div>';
					$divContent .='</div>';
				
				$divContent .='</div>';

				$divContent .= '<div class="col-md-6 col-sm-12 mt-2">';
				$phones=explode("|", $_SESSION['PTO_DETAILS'][$codigo][$attr]['telefonos']);
				if(is_array($phones) && count($phones)){
					foreach ($phones as $phone) {
						$divContent .= '<div class="phones"> Telefonos: '.trim($phone).'</div>';
					}
				}
				
				//@fixme
				$divContent .= '<div class="Whatsapp"> Whatsapp: '.$_SESSION['PTO_DETAILS'][$codigo][$attr]['whatsapp'].'</div>';
				$divContent .= '</div>';

				$html = '<div class="row">'.$divContent.'</div>';

				return $html;
			}
			if ($attr == 'horarios' && isset($_SESSION['PTO_DETAILS'][$codigo][$attr]) ){
				$divContent ='';
				foreach ($_SESSION['PTO_DETAILS'][$codigo][$attr] as $value) {
					$divContent .= '<div class="col-md-6 col-sm-12 mt-2 text-dec">'.$value.'</div>';
				}
				$html = '<div class="row">'.$divContent.'</div>';
				return $html;
			}
			if ($attr == 'comoLlegar' && isset($_SESSION['PTO_DETAILS'][$codigo][$attr]) ){	
				$divContent ='';
					//if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['descripcion']) && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['descripcion'])) {
						$divContent .= '<div class="col-12 divider-bottom">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['descripcion'].'</div>';
					//}

					//if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['vehiculoPropio']) && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['vehiculoPropio'])) {
						$divContent .= '<div class="col-4 divider-bottom howToGet">VEHÍCULO PROPIO: </div>';
						$divContent .= '<div class="col-8 divider-bottom">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['vehiculoPropio'].'</div>';
					//}

					//if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['transportePublico']) && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['transportePublico'])) {
						$divContent .= '<div class="col-4 divider-bottom howToGet">TRANSPORTE PÚBLICO: </div>';
						$divContent .= '<div class="col-8 divider-bottom">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['transportePublico'].'</div>';
					//}

					//if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['EstacionMetroCercana']) && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['EstacionMetroCercana'])) {
						$divContent .= '<div class="col-4 divider-bottom howToGet">ESTACION DE METRO CERCANA: </div>';
						$divContent .= '<div class="col-8 divider-bottom">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['EstacionMetroCercana'].'</div>';
					//}

					//if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['puntoReferencia']) && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['puntoReferencia'])) {
						$divContent .= '<div class="col-4 howToGet">PUNTO DE REFERENCIA: </div>';
						$divContent .= '<div class="col-8">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['puntoReferencia'].'</div>';
					//}
				$html = '<div class="row">'.$divContent.'</div>';

				return $html;
			}
			if ($attr == 'caracteristicasPresentes' && isset($_SESSION['PTO_DETAILS'][$codigo][$attr]) ) {	

				$divContent ='<div class="col-md-6 col-sm-12">';
					if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['discapacitados']) && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['discapacitados'])) {
						$divContent .= '<div class="discapacitados">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['discapacitados'].'</div>';
					}

					if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['estacionamientoGratis']) && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['estacionamientoGratis'])) {
						$divContent .= '<div class="estacionamientoGratis">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['estacionamientoGratis'].'</div>';
					}
				$divContent .='</div>';

				$divContent .= '<div class="col-md-6 col-sm-12">';
					if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['estacionamientoPago']) && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['estacionamientoPago'])) {
						$divContent .= '<div class="estacionamientoPago">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['estacionamientoPago'].'</div>';
					}

					if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['recogerPaquete']) && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['recogerPaquete'])) {
						$divContent .= '<div class="recogerPaquete">'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['recogerPaquete'].'</div>';
					}
				$divContent .= '</div>';

				$html = '<div class="row dark-blue-background">'.$divContent.'</div>';

				return $html;
			}
			if ($attr == 'mapa' && isset($_SESSION['PTO_DETAILS'][$codigo][$attr]) ) {
				$divContent= '';
				if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['googleMapUrl'])  && !empty($_SESSION['PTO_DETAILS'][$codigo][$attr]['googleMapUrl'])) {
					$divContent .= '<div class="col-12">'.trim($_SESSION['PTO_DETAILS'][$codigo][$attr]['googleMapUrl']).'</div>';
				}
				/*
				if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['latitud']) && isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['length'])) {
					$divContent .= '<div class="col-12"><a href="https://www.google.com/maps/place/'.$_SESSION['PTO_DETAILS'][$codigo][$attr]['latitud'].','.$_SESSION['PTO_DETAILS'][$codigo][$attr]['length'].'"> <img   style="width: 100%;" src="/wp-content/uploads/2021/09/mapa.png" />
									</a></div>';
				}
				*/
				if (isset($_SESSION['PTO_DETAILS'][$codigo][$attr]['zonasCubiertas'])) {
					$divContent .= '<div class="col-12 my-4">Zonas cubiertas por esta oficina para entregas a domicilio:</div>';
						$zonascubiertas=explode("|", $_SESSION['PTO_DETAILS'][$codigo][$attr]['zonasCubiertas']);
						if(is_array($zonascubiertas) && count($zonascubiertas)){
							foreach ($zonascubiertas as $zona) {
								$divContent .= '<div class="col-md-4 col-sm-6"> <div class="offices-selection"><h6 id="flush-headingOne">'.trim($zona).'</h6></div></div>';
							}
						}
				}

				$html = '<div class="row">'.$divContent.'</div>';

				return $html;
			}
			if ($attr == 'oficinasCercanas'){
				$divContent ='';
				
				$htmlOficinasCercanas='';
				foreach ($_SESSION['PTO_DETAILS'][$codigo]['mapa'][$attr] as $oficinaCercana) {
					if(isset($oficinaCercana['name']) && isset($oficinaCercana['distanceMts']) && isset($oficinaCercana['code']) ){
						$distancia=doubleval($oficinaCercana['distanceMts'])/1000;
						$distancia=number_format($distancia, 3, '.', ' ');
						$htmlOficinasCercanas.='<div class="col-md-6 col-sm-6">';
						$htmlOficinasCercanas.='	<div class="offices-selection">';
						$htmlOficinasCercanas.='		<h6 id="flush-headingOne">';
						$htmlOficinasCercanas.='			<span style="color: #0000ff;">'.$distancia.' Km. </span> ';
						$htmlOficinasCercanas.='			<span> &nbsp; '.$oficinaCercana['name'].' | '.$oficinaCercana['code'].'</span>';
						$htmlOficinasCercanas.='		</h6>';
						$htmlOficinasCercanas.='	</div>';
						$htmlOficinasCercanas.='</div>';
					}
				}

				$divContent = '<hr style="margin-top:-12px;">
				<p>Otras de nuestras oficinas cercanas a esta ubicación:</p>
				<div class="row" style="display: flex; flex-wrap: wrap;">';
					$divContent.=$htmlOficinasCercanas;
				$divContent.='</div>';
				$divContent = '<div class="row">'.$divContent.'</div>';
				
				return $divContent;
			}
		}
	}

	public function logos_tealca_call_office($code){
		$responseGlobal= [
			'typeResponse' => 'error',
			'office' => [],
			'error' => '',
			'token' => null
		];

		try {
			if( is_null($this->api_url) || is_null($this->api_user) || is_null($this->api_password) ) { 
				throw new Exception('Credenciales de Api Oficinas Tealca incompletas o no configuradas.');
			}

			$token = $this->authApi();

			if( is_null($token) ){
				throw new Exception('Token de API Tealca no obtenido.');
			}
			

			$args = array(
					'headers' => array(
						'Authorization' => 'Bearer '.$token,
						'Content-Type' => 'application/json'
					),
					'timeout'=> 300,
				);
			$response = wp_remote_get($this->api_url.'BusinessUnit/'.$code.'?nearbyBusinessUnit=true', $args);
			
			if(is_wp_error($response)) {
				throw new Exception('Ha ocurrido un error al obtener las oficinas de la api de tealca. '.json_encode($response));
			}else{
				$responseBody = wp_remote_retrieve_body($response);
				$responseGlobal['office']=json_decode($responseBody, true);
				$responseGlobal['typeResponse']= 'success';
				$responseGlobal['token']= $token;
			}
		} catch (\Throwable $th) {
			$responseGlobal['error']=$th->getMessage();
		}

		return $responseGlobal;
	}

	public function authApi(){
		$url = $this->api_url.'Account/Login';
		//Get Token
		$requestToken = wp_remote_post($this->api_url.'account/login', [
			'method'      => 'POST',
			'headers' => array(
				'Content-Type' => 'application/json',
			),
			'timeout'=> 300,
			'body'        => wp_json_encode([
				'login' => $this->api_user,
				'password' => $this->api_password
			])
		]);
		
		$token=null;
		if ( is_wp_error( $requestToken ) ) {
			$response = $requestToken->get_error_message();
			throw new Exception('Ha ocurrido un error al obtener el token de la Api Tealca. '.($response));
		}else{
			$response = json_decode( wp_remote_retrieve_body( $requestToken ),true);
			$token=(isset($response['token']))?$response['token']:null;
		}

		return $token;
	}

	private function getOfficeAtrr($attrs){
		
		$attributes = array_map(function($attr){
			$array[$attr['attributeName']] = $attr['attributeValue'];
			return $array;
		},$attrs);
		
		$result = array_merge_recursive(...$attributes);
		return $result;
	}

	private function mapAtrrOffice($attrsMap, $office){
		
		foreach ($attrsMap as $key => $value) {
			$attrs = array_merge_recursive( $value, $office);
		}
		
		$details = $this->getOfficeAtrr($attrs['attributes']);
		$map = array_merge_recursive($details,$attrs);
		unset($map['attributes']);

		
		return $map;
	}

	private function setSessionPTO($codigo, $officeDetails){
		$_SESSION['PTO_DETAILS'][$codigo]=
			[
				'timeExpiration'  	      => time(),
				'resumen'			      => [
					'name'					=> isset($officeDetails['name'])	 ? $officeDetails['name']								: '',
					'codigo'				=> isset($officeDetails['code']) 	 ? $officeDetails['code']								: '',
					'ciudad'				=> isset($officeDetails['cityName']) ? $officeDetails['cityName']							: ''
				], 
				'detallesDeContacto'      => [
					'direccion'       		=> isset($officeDetails['address']) ? $officeDetails['address'] 							: '',
					'telefonos' 	  		=> isset($officeDetails["Teléfono"]) ? $officeDetails["Teléfono"] 							: '',
					'whatsapp'				=> isset($officeDetails["Whatsapp"]) ? $officeDetails["Whatsapp"] 							: '',
					'email'					=> isset($officeDetails['email']) 	  ? $officeDetails['email']     							: '',
					'instagram'				=> isset($officeDetails['instagram']) ? $officeDetails['instagram'] 							: ''
				],
				'horarios'   			  => isset($officeDetails["WorkingHours"]) ? $officeDetails["WorkingHours"] 						: [],
				'comoLlegar' 			  => [
					'descripcion' 			=> 'A continuación te indicamos las distintas opciones para acercarte a esta oficina utilizando transporte privado o público, te recomendamos tomar en cuenta los horarios de trabajo y los tiempos de tránsito según tu ubicación:',
					'vehiculoPropio' 		=> isset($officeDetails['vehiculoPropio']) 	? $officeDetails[0]['vehiculoPropio']		: '',
					'transportePublico' 	=> isset($officeDetails['transportePublico']) 	? $officeDetails[0]['transportePublico']		: '',
					'EstacionMetroCercana'  => isset($officeDetails['DD-EstacionMetro']) 	? $officeDetails['DD-EstacionMetro'] 		: '',
					'puntoReferencia' 		=> isset($officeDetails['puntoReferencia']) 	? $officeDetails[0]['puntoReferencia']		: ''
				],
				'caracteristicasPresentes' =>[
					'discapacitados'		=> isset($officeDetails['DD-Acceso Discapacitados']) && $officeDetails['DD-Acceso Discapacitados'] 	== true ? 'AMIGABLE PARA DISCAPACITADOS' 	: '',// 'NO AMIGABLE PARA DISCAPACITADOS',
					'estacionamientoGratis' => isset($officeDetails['DD-Estacionamiento Gratis']) && $officeDetails['DD-Estacionamiento Gratis'] == true ? 'ESTACIONAMIENTO GRATUITO DISPONIBLE' 	: '',// 'ESTACIONAMIENTO GRATUITO NO DISPONIBLE',
					'estacionamientoPago'	=> isset($officeDetails['DD-Estacionamiento Pago']) && $officeDetails['DD-Estacionamiento Pago'] == true ? 'ESTACIONAMIENTO DE PAGO DISPONIBLE' 	: '',// 'ESTACIONAMIENTO DE PAGO NO DISPONIBLE',
					'recogerPaquete'		=> isset($officeDetails['DD-Recoger Paquete']) && $officeDetails['DD-Recoger Paquete'] == true ? 'RECOGIDA DE PAQUETES DISPONIBLE' 				: '',// 'RECOGIDA DE PAQUETES NO DISPONIBLE'
				],
				'mapa'					  => [
					'latitud'				=> isset($officeDetails['latitude']) ? $officeDetails['latitude'] : '',
					'length'				=> isset($officeDetails['length'])   ? $officeDetails['length']   : '',
					'zonasCubiertas'		=> isset($officeDetails['ZonasCubiertas']) && $officeDetails['ZonasCubiertas'] == true ? $officeDetails['ZonasCubiertas'] 	: '',
					'googleMapUrl'			=> $officeDetails['url_google_map'],
					'oficinasCercanas'		=> (isset($officeDetails['nearbyBusinessUnits']) && is_array($officeDetails['nearbyBusinessUnits']))? $officeDetails['nearbyBusinessUnits']:[],
				]
			];
	}


		


	// GETTERS METHODS
	public function get_api_url() {
		return isset($this->options['api_url']) ? $this->options['api_url'] : null;
	}

	public function get_api_user() {
		return isset($this->options['api_user']) ? $this->options['api_user'] : null;
	}

	public function get_api_password() {
		return isset($this->options['api_password']) ? $this->options['api_password'] : null;
	}

	public function is_debug_enable() {
		return isset($this->options['debug']) ? $this->options['debug']=='on':false;
	}

	/**
	 * Get a list of cities by state
	 *
	 * @since    1.0.0
	 */
	public function logos_tealca_get_cities(WP_REST_Request $request)
	{
		// State ID
		$id = $request['id'];

		$cities = get_categories(array(
			'taxonomy' => 'ubicaciones',
			'order'   => 'ASC',
			'parent'  => $id
		));

		foreach ($cities as $city) {
			$latitud = get_field('latitud', 'term_' . $city->term_id);

			$longitud = get_field('longitud', 'term_' . $city->term_id);

			$zoom = get_field('zoom', 'term_' . $city->term_id);

			$city->latitud = $latitud;

			$city->longitud = $longitud;

			$city->zoom = $zoom;
		}

		$cities = json_encode($cities);

		$response = array(
			'success' => true,
			'data' => $cities
		);

		wp_send_json($response);
	}

	/**
	 * Get a list of offices by locations
	 *
	 * @since    1.0.0
	 */

	public function logos_tealca_get_offices()
	{

		$allDataOffices = [];

		if ($this->offices->have_posts()) {
			while ($this->offices->have_posts()) {
				$this->offices->the_post();

				$title = get_the_title();

				$id = get_the_ID();

				$slug = get_post_field( 'post_name', get_the_ID() );

				$featured_img_url = get_the_post_thumbnail_url($id, 'full');

				$taxonomies = wp_get_post_terms($id, 'ubicaciones',  array("fields" => "all"));
				$taxonomies_filtered = '';
				
				foreach ($taxonomies as $tax) {
					$taxonomies_filtered .= $tax->name . ' ';
				}

				$officeData = [
					'post' => [
						'id'  => $id,
						'name' => $title,
					],
					'fields' => get_fields(),
					'image' =>  $featured_img_url,
					'ubicaciones' => $taxonomies_filtered,
					'slug' => $slug 
				];

				array_push($allDataOffices,	$officeData);
			}
		}


		$response = array(
			'success' => true,
			'data' => $allDataOffices,
		);

		wp_send_json($response);
	}
}