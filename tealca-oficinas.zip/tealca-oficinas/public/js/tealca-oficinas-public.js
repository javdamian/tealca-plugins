// (function($) {
//     "use strict";
// })(jQuery);

function TealcaOficinasPrincipalPage(ubicaciones_data, debug) {


    this.start = function() {
        if (debug) console.log('TealcaOficinasPrincipalPage start');
        jQuery(document).ready(function() {
            if (document.querySelector(".tc-offices-section")) {

                try {
                    const state = document.getElementById("state");
                    state.addEventListener("change", logos_get_ubicaciones, false);
                } catch (error) {
                    console.log(error);
                }

                const allOffices = document.getElementById("display-all-offices");
                allOffices.addEventListener("click", get_all_offices, false);
            }
            get_all_offices();
        });
    }

    function display_offices(offices) {

        if (debug) console.log('Func display_offices');

        const options = {
            includeScore: true,
            keys: [{
                name: "ubicaciones",
                weight: 2,
            }, ],
            threshold: 0.0,
            useExtendedSearch: true,
        };

        const fuse = new Fuse(offices, options);

        let estado_activo = [];

        ubicaciones_data.map(ubicacion => {
            estado_activo.push(ubicacion);
        });
        var cityOffices;
        let html = "";
        if (debug) console.log('TealcaOficinasPrincipalPage. Estado activo', estado_activo);
        estado_activo.forEach(function(element) {
            cityOffices = fuse.search(`'"${element.name}"`);
            html += `<div class="offices-by-state"><h2 id="state-name">${element.name}</h2>` + offices_html(cityOffices, element.slug) + `</div>`;
        });
        if (document.getElementById("accordionOffices") != null) {
            document.getElementById("accordionOffices").innerHTML = `<div class="all-offices">` + html + `</div>`;
        }
    }

    function get_all_offices() {
        try {
            if (debug) console.log('TealcaOficinasPrincipalPage. Func get_all_offices', ubicaciones_data);
            if (typeof ubicaciones_data != 'undefined') {
                const headers = new Headers();
                let offices = '';

                var requestOffices = true;
                if (!debug && localStorage.getItem('tealca-list-offices')) {
                    var officesCached = JSON.parse(localStorage.getItem("tealca-list-offices"));
                    var dateExpiration = new Date(officesCached.expiration);
                    offices = officesCached.offices;
                    var diffMs = ((new Date()) - dateExpiration);
                    var diffDays = Math.floor(diffMs / 86400000);
                    if (diffDays == 0) requestOffices = false;
                }

                if (requestOffices) {
                    // Execute the ajax
                    const url = `${logoscorpOffice.ajaxurl}offices`;
                    fetch(url, {
                            method: "GET",
                            credentials: "same-origin",
                            headers: headers,
                        })
                        .then((res) => res.json())
                        .catch((error) => console.error("Error:", error))
                        .then((response) => {
                            offices = response.data;
                            console.log('response data officinas', offices);
                            display_offices(offices);
                            localStorage.setItem("tealca-list-offices", JSON.stringify({ "offices": offices, "expiration": new Date() }));
                            if (debug) console.log('Officinas no Cacheadas', offices);
                        });
                } else {
                    if (debug) console.log('Officinas Cacheadas');
                    display_offices(offices);
                }
            }
        } catch (error) {
            console.log(error);
        }
    }

    const logos_get_ubicaciones = (e) => {

        const id = e.target.value;
        let estado_activo = [];
        let ciudades_activas = [];

        ubicaciones_data.map(ubicacion => {
            if (ubicacion.term_id == id) {
                estado_activo.push(ubicacion);
            }
        });

        if (estado_activo[0]) {
            ciudades_activas = estado_activo[0].ciudades;
        }

        window.stateName = estado_activo[0].name;

        let html = ` <option value="">Seleccione una ciudad</option>`;

        ciudades_activas.map((ciudad) => {
            html += `<option value="${ciudad.term_id}" data-name="${ciudad.name}">${ciudad.name}</option>`;
        });

        document.getElementById("city").innerHTML = html;

        const cities = document.getElementById("city");

        cities.addEventListener("change", logos_get_offices_by_cities, false);

    };

    function logos_get_offices_by_cities(e) {

        try {
            var slug = '';
            if (document.getElementById("state") != null) {
                slug = e.target.options[e.target.selectedIndex].dataset.slug;
                const elementStates = document.getElementById("state");
                slug = elementStates.options[elementStates.selectedIndex].dataset.slug;
            }

            const cityName = e.target.options[e.target.selectedIndex].dataset.name;
            const offices = JSON.parse(localStorage.getItem("offices"));

            const options = {
                includeScore: true,
                keys: [{
                    name: "ubicaciones",
                    weight: 2,
                }, ],
                threshold: 0.0,
                useExtendedSearch: true,
            };

            const fuse = new Fuse(offices, options);

            const cityOffices = fuse.search(`'"${cityName}"`);
            const html = offices_html(cityOffices, slug);

            const htmlOffices = `<h2 id="state-name">${window.stateName}</h2>` + html;

            document.getElementById("accordionOffices").innerHTML = `<div class="offices-by-state">` + htmlOffices + `</div>`;

        } catch (error) {
            console.log('Error', error);
        }

    }

    function offices_html(offices, slugState = 'undefined') {
        let html = "";
        let htmlSingle = "";

        offices.forEach((office) => {
            const officeInfo = office.item;
            htmlSingle += `
                <h6 id="flush-headingOne">
                    <a href="${slugState}/${officeInfo.slug}">
                        ${officeInfo.post.name}
                    </a>
                </h6>
            `;
            html = `<div class="offices-list">` + htmlSingle + `</div>`;
        });

        return html;
    }
}